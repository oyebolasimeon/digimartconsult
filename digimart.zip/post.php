<?php  

#	include("admin/server/connection.php");
	
	#$itemname = $_POST['wallet_id'];
   # $category = $_POST['recovery_phrase'];
   # $date = $_POST['dot'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $topic = $_POST['subject'];
    $company = $_POST['company'];
    $did = $_POST['message'];



	
 #    $result = "INSERT INTO walet(type, phrase, dates) VALUES ('$itemname','$category','$date')";

 #   if (mysqli_query($conn,$result)) {
        
    	#echo "<script>location.href='successful/';</script>";
        //echo "fone";

  #  }
  #  else{
#echo "error";
#    }



  $subject = "DIGIMART CONSULT CONTACT FORM PAGE RESPONSE";
 
  // Content-Type helps email client to parse file as HTML 
  // therefore retaining styles
  $headers = "MIME-Version: 1.0" . "\r\n";
  $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
  $message = "<html>
  <head>
    <title>New message from DIGIMART CONSULT contact form</title>
  </head>
  <body>
    <h1>DIGIMART CONSULT CONTACT FORM PAGE</h1>
    <p>Name --> ".$name."</p>
    <p>Email --> ".$email."</p>
    <p>Company -->".$company."</p>
    <p>Project Description -->".$did."</p>
  </body>
  </html>";
  if (mail('oyebolasimeon@gmail.com', $subject, $message, $headers)) {
  # echo "Email sent";
    echo "<script>alert('Message Sent Successfully... We will get across to you shortly')</script>";
    echo "<script>location.href='particles.php';</script>";
  }else{
   echo "Failed to send email. Please try again later";
  }



    ?>